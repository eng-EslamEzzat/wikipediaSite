###Eslam is the Programer###
*wow*
this is an edit